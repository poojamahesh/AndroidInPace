package com.gimbal.android.sample;

import com.parse.Parse;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Leaderboard extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_leaderboard);
		final TextView scoreboard = (TextView) findViewById(R.id.scoreboard);
		// -----Parse code
		Parse.enableLocalDatastore(this);

		Parse.initialize(this, "NEgy5OqvwjZwvrbIQJ05Iq9AqbxQmBSrjjIIUnua",
				"AgnzIyxpGjwCEaJopc6KQXaSWCywYgQ0qrBWkaJC");

		final ParseObject gameScore = new ParseObject("TestData");

		gameScore.put("score", 1);
		gameScore.put("playerName", "Adarsh");
		gameScore.put("cheatMode", false);
		gameScore.saveInBackground();

		// Retrieving Objects
		ParseQuery<ParseObject> query = ParseQuery.getQuery("TestData");

		// Retrieve the most recent ones
		query.orderByDescending("createdAt");

		// Only retrieve the last ten
		query.setLimit(10);

		final int score = gameScore.getInt("score");
		final String playerName = gameScore.getString("playerName");
		boolean cheatMode = gameScore.getBoolean("cheatMode");

		scoreboard.setText(playerName + "         " + score);

		gameScore.increment("score");
		//gameScore.increment("rnIOGhqSQb",2);
		gameScore.saveInBackground();
		/*Button b = (Button) findViewById(R.id.back);

		b.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(),
						AppActivity.class);
				startActivity(intent);
			}
		});*/
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.leaderboard, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
}
